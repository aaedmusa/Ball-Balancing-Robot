%% ____________________
%% INITIALIZATION
clc
clear

% defines x, y, and z array indexes to be used
[x, y, z] = deal(1, 2, 3);

%% ____________________
%% INPUT VALUES
n = [0.1, 0.1, 1]; % normal vector
n = n/mag(n); % converts vector 'n' to a unit vector

h = [0, 0, 4]; % center point of the platform
a(x) = 0.01; % x component of point af

% input user defined lengths
l0 = 2.875;
lf = 2.375;
d1 = 1;
d2 = 1.625;
m = 0.5;
p1 = 1;
p2 = 4.375;

%% ____________________
%% MAIN CODE

while(1)
    choice1 = menu("Choose an Option ","Play Demo","Enter Values", "Exit");
    
    if(choice1 == 1)
        step = 0.15; %for loop increment amount
        time = 0;
        
        for i = -0.2:step:0.2
         n = [i, 0, 1];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 0.2:-step:0
         n = [i, 0, 1];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 4:step:4.7
         h = [0, 0, i];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 4.7:-step:4
         h = [0, 0, i];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 0.01:step:1
         a(x) = i;
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 1:-step:-1
         a(x) = i;
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = -1:step:0.01
         a(x) = i;
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 0:step:1
         h = [i, 0, 4];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 0:step:2*pi
         h = [cos(i), sin(i), 4];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 1:-step:0
         h = [i, 0, 4];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
        
        for i = 0:step:2*pi
         n = [0.1*cos(i), 0.1*sin(i), 1];
         output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         pause(time);
        end
    
    else if(choice1 == 2)
        choice2 = menu("Choose an Option ","Change Normal Vector","Change Height Point", "Change Twist");
        if (choice2 == 1)
            while(1)
                n(x) = input("\nEnter nx: ");
                if(n(x) == 444)
                    break
                end
                n(y) = input("Enter ny: ");
                if(n(y) == 444)
                    break
                end
                n(z) = input("Enter nz: ");
                if(n(z) == 444)
                    break
                end
                output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
            end
        end
        if (choice2 == 2)
            while(1)
                h(x) = input("\nEnter hx: ");
                if(h(x) == 444)
                    break
                end
                h(y) = input("Enter hy: ");
                if(h(y) == 444)
                    break
                end
                h(z) = input("Enter hz: ");
                if(h(z) == 444)
                    break
                end
                output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
            end
        end
        
        if (choice2 == 3)
            while(1)
                a(x) = input("\nEnter ax: ");
                if(a(x) == 444)
                    break
                end
                output_model(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
            end
        end
    else
        break
    end
    end
end

