function value = dot(array1, array2) % finds the dot product of two vectors
    value = sum(array1.*array2);
end