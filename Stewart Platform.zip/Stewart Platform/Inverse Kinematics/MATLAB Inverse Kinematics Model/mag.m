function value = mag(array) % finds the magnitude of a vector
    value = sqrt(sum(array.^2));
end