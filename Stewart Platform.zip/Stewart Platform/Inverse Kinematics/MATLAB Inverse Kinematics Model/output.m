function output = output(n, h, ax, l0, lf, d1, d2, m, p1, p2) % calcuates all theta values
    %% ____________________
    %% INITIALIZATION
    % defines x, y, and z array indexes to be used
    [x, y, z] = deal(1, 2, 3);
    a(x) = ax;

    %% ____________________
    %% CONSTANT CALCULATIONS
    toDeg = 180/pi; % radians to degrees conversion factor 
    
    %calculates normal vectors nab, nac, and nbc for each side of the triangle
    nab = [sqrt(3)/2, -1/2, 0];
    nac = [sqrt(3)/2, 1/2, 0];
    nbc = [0, 1, 0];
    
    % intermediate variables
    t = (lf^2*sqrt(3))/2;
    u = sqrt(l0^2+d1^2)*sin((2*pi/3)-atan(l0/d1)); %(2*pi/3 is 120 degrees)
    
    % calculates points a10, a20, b10, b20, c10, and c20
    a10 = [d2-u*sqrt(3), -u-d2*sqrt(3), 0]*0.5; 
    a20 = [-a10(x), a10(y), 0];
    b10 = [u*sqrt(3)+d2, d2*sqrt(3)-u, 0]*.5;
    b20 = [d2, u, 0];
    c10 = [-b20(x), b20(y), 0];
    c20 = [-b10(x), b10(y), 0];
    
    % calculates vectors, ab, ac, and bc
    ab = a20 - b10;
    ac = a10 - c20;
    bc = b20 - c10;
    
    %% ____________________
    %% STAGE 1 CALCULATIONS
    % in regards to e, g, and k indexes 1, 2, and 3 are a, b, and c respectively
    
    % af components
    e(1) = a(x)-h(x); % 'ea'
    a(z) = ((n(y)*sqrt(lf^2*(1-n(x)^2)-e(1)^2)-n(z)*n(x)*e(1))/(1-n(x)^2))+h(z); % 'az'
    g(1) = a(z)-h(z); % calculates 'ga'
    a(y) = h(y)-sqrt(lf^2-g(1)^2-e(1)^2); % 'ay'
    k(1) = a(y)-h(y); % 'ka'
    
    w = sqrt(3)*(n(x)*g(1)-n(z)*e(1)); % intermediate variable
    
    % bf components
    b(y) = h(y)+((sqrt(w^2-3*lf^2*(1-n(y)^2)+(2*k(1))^2)-w)/2); % 'by'
    k(2) = b(y)-h(y); % 'kb'
    b(x) = ((e(1)*k(2)-n(z)*t)/k(1)) +h(x); % 'bx'
    e(2) = b(x)-h(x); % 'eb'
    b(z) = ((n(x)*t+g(1)*k(2))/k(1))+h(z); %'bz'
    g(2) = b(z)-h(z); % 'gb'
    
    % cf components
    c(y) = h(y)+((w+sqrt(w^2-3*lf^2*(1-n(y)^2)+(2*k(1))^2))/2); % 'cy'
    k(3) = c(y)-h(y); % 'kc'
    c(x) = ((e(1)*k(3)+n(z)*t)/k(1)) +h(x); % 'cx'
    e(3) = c(x)-h(x); % 'ec'
    c(z) = ((g(1)*k(3)-n(x)*t)/k(1))+h(z); % 'cz'
    g(3) = c(z)-h(z); % 'gc'
    
    %% ____________________
    %% STAGE 2 CALCULATIONS
    
    % a1
    a1f(x) = a(x)+(m/lf)*(n(z)*k(1)-n(y)*g(1)); % a1fx
    a1f(y) = a(y)+((a1f(x)-a(x))*k(1)-n(z)*lf*m)/e(1); % a1fy
    a1f(z) = a(z)+(n(y)*lf*m+(a1f(x)-a(x))*g(1))/e(1); % a1fz
    a1 = a1f - a10; % vector 'a1'
    
    % a2
    a2f(x) = 2*a(x)-a1f(x); % a2fx
    a2f(y) = 2*a(y)-a1f(y); % a2fy
    a2f(z) = 2*a(z)-a1f(z); % a2fz
    a2 = a2f - a20; % vector 'a2'
    
    % b1
    b1f(x) = b(x)+(m/lf)*(n(z)*k(2)-n(y)*g(2)); % b1fx
    b1f(y) = b(y)+((b1f(x)-b(x))*k(2)-n(z)*lf*m)/e(2); % b1fy
    b1f(z) = b(z)+(n(y)*lf*m+(b1f(x)-b(x))*g(2))/e(2); % b1fz
    b1 = b1f - b10; % vector 'b1'
    
    % b2
    b2f(x) = 2*b(x)-b1f(x); % b2fx
    b2f(y) = 2*b(y)-b1f(y); % b2fy
    b2f(z) = 2*b(z)-b1f(z); % b2fz
    b2 = b2f - b20; % vector 'b2'
    
    % c1
    c1f(x) = c(x)+(m/lf)*(n(z)*k(3)-n(y)*g(3)); % c1fx
    c1f(y) = c(y)+((c1f(x)-c(x))*k(3)-n(z)*lf*m)/e(3); % c1fy
    c1f(z) = c(z)+(n(y)*lf*m+(c1f(x)-c(x))*g(3))/e(3); % c1fz
    c1 = c1f - c10; % vector 'c1'
    
    % c2
    c2f(x) = 2*c(x)-c1f(x); % c2fx
    c2f(y) = 2*c(y)-c1f(y); % c2fy
    c2f(z) = 2*c(z)-c1f(z); % c2fz
    c2 = c2f - c20; % vector 'c2'
    
    %% ____________________
    %% STAGE 3 CALCULATIONS
    
    % theta(1)
    a1s = sum(a1.*nac)*nac; % vector 'a1s'
    mag_a1s = sqrt(sum(a1s.^2)); % magnitude of vector 'a1s'
    a1_proj = a1 - a1s; % projection of vector 'a1' onto the ac plane
    mag_a1_proj = sqrt(sum(a1_proj.^2)); % magnitude of vector 'a1' projected on the ac plane
    mag_p2a1 = sqrt(p2^2-mag_a1s^2); % magnitude of link p2 projected on the ac plane
    theta(1) = acos(-sum(a1_proj.*ac)/(2*d2*mag_a1_proj)); % theta a1
    theta(1) = (theta(1) - acos((mag_a1_proj^2+p1^2-mag_p2a1^2)/(2*mag_a1_proj*p1)))*toDeg; % theta a1 continued calculation
    
    % theta(2)
    a2s = sum(a2.*nab)*nab; % vector 'a2s'
    mag_a2s = sqrt(sum(a2s.^2)); % magnitude of vector 'a2s'
    a2_proj = a2-a2s; % projection of vector 'a2' onto the ab plane
    mag_a2_proj = sqrt(sum(a2_proj.^2)); % magnitude of vector 'a2' projected on the ab plane
    mag_p2a2 = sqrt(p2^2-mag_a2s^2); % magnitude of link p2 projected on the ab plane
    theta(2) = acos(-sum(a2_proj.*ab)/(2*d2*mag_a2_proj)); % theta a2
    theta(2) = (theta(2) - acos((mag_a2_proj^2+p1^2-mag_p2a2^2)/(2*mag_a2_proj*p1)))*toDeg; % theta a2 continued calculation
    
    % theta(3)
    b1s = sum(b1.*nab)*nab; % vector 'b1s'
    mag_b1s = sqrt(sum(b1s.^2)); % magnitude of vector 'b1s'
    b1_proj = b1 - b1s; % projection of vector 'b1' onto the ab plane
    mag_b1_proj = sqrt(sum(b1_proj.^2)); % magnitude of vector 'b1' projected on the ab plane
    mag_p2b1 = sqrt(p2^2-mag_b1s^2); % magnitude of link p2 projected on the ab plane
    theta(3) = acos(sum(b1_proj.*ab)/(2*d2*mag_b1_proj)); % theta b1
    theta(3) = (theta(3) - acos((mag_b1_proj^2+p1^2-mag_p2b1^2)/(2*mag_b1_proj*p1)))*toDeg; % theta b1 continued calculation
    
    % theta(4)
    b2s = sum(b2.*nbc)*nbc; % vector 'b2s'
    mag_b2s = sqrt(sum(b2s.^2)); % magnitude of vector 'b2s'
    b2_proj = b2 - b2s; % projection of vector 'b2' onto the bc plane
    mag_b2_proj = sqrt(sum(b2_proj.^2)); % magnitude of vector 'b2' projected on the bc plane
    mag_p2b2 = sqrt(p2^2-mag_b2s^2); % magnitude of link p2 projected on the bc plane
    theta(4) = acos(-sum(b2_proj.*bc)/(2*d2*mag_b2_proj)); % theta b2
    theta(4) = (theta(4) - acos((mag_b2_proj^2+p1^2-mag_p2b2^2)/(2*mag_b2_proj*p1)))*toDeg; % theta b2 continued calculation
    
    % theta(5)
    c1s = sum(c1.*nbc)*nbc; % vector 'c1s'
    mag_c1s = sqrt(sum(c1s.^2)); % magnitude of vector 'c1s'
    c1_proj = c1 - c1s; % projection of vector 'c1' onto the bc plane
    mag_c1_proj = sqrt(sum(c1_proj.^2)); % magnitude of vector 'c1' projected on the bc plane
    mag_p2c1 = sqrt(p2^2-mag_c1s^2); % magnitude of link p2 projected on the bc plane
    theta(5) = acos(sum(c1_proj.*bc)/(2*d2*mag_c1_proj)); % theta c1
    theta(5) = (theta(5) - acos((mag_c1_proj^2+p1^2-mag_p2c1^2)/(2*mag_c1_proj*p1)))*toDeg; % theta c1 continued calculation
    
    %theta(6)
    c2s = sum(c2.*nac)*nac; % vector 'c2s'
    mag_c2s = sqrt(sum(c2s.^2)); % magnitude of vector 'c2s'
    c2_proj = c2 - c2s; % projection of vector 'c2' onto the ac plane
    mag_c2_proj = sqrt(sum(c2_proj.^2)); % magnitude of vector 'c2' projected on the ac plane
    mag_p2c2 = sqrt(p2^2-mag_c2s^2); % magnitude of link p2 projected on the ac plane
    theta(6) = acos(sum(c2_proj.*ac)/(2*d2*mag_c2_proj)); % theta c2
    theta(6) = (theta(6) - acos((mag_c2_proj^2+p1^2-mag_p2c2^2)/(2*mag_c2_proj*p1)))*toDeg; % theta c2 continued calculation
    
    %% ____________________
    %% ERROR CHECK
    check = 0;
    for i = 1:6
        if(abs(theta(i)) >= 60 || isnan(theta(i))) % if an angle is greater than 60 degrees than the program cannot be executed
            check = 1;
        end
    end

    if(check == 1)
        fprintf("\nERROR: CURRENT VALUES CANNOT BE EXECUTED\n");
    else
        
    %% ____________________
    %% OUTPUT VALUES
    
    %{
    %display points
    
    % af, a10, a20, a1f, a2f points
    fprintf("af = (%0.3f, %0.3f, %0.3f)\n", a(x), a(y), a(z)); 
    fprintf("a10 = (%0.3f, %0.3f, %0.3f)\n", a10(x), a10(y), a10(z));
    fprintf("a20 = (%0.3f, %0.3f, %0.3f)\n", a20(x), a20(y), a20(z));
    fprintf("a1f = (%0.3f, %0.3f, %0.3f)\n", a1f(x), a1f(y), a1f(z));
    fprintf("a2f = (%0.3f, %0.3f, %0.3f)\n", a2f(x), a2f(y), a2f(z));
    
    fprintf("\n");
    
    % bf, b10, b20, b1f, b2f points
    fprintf("bf = (%0.3f, %0.3f, %0.3f)\n", b(x), b(y), b(z)); 
    fprintf("b10 = (%0.3f, %0.3f, %0.3f)\n", b10(x), b10(y), b10(z));
    fprintf("b20 = (%0.3f, %0.3f, %0.3f)\n", b20(x), b20(y), b20(z));
    fprintf("b1f = (%0.3f, %0.3f, %0.3f)\n", b1f(x), b1f(y), b1f(z));
    fprintf("b2f = (%0.3f, %0.3f, %0.3f)\n", b2f(x), b2f(y), b2f(z));
    
    fprintf("\n");
    
    % cf, c10, c20, c1f, c2f points
    fprintf("cf = (%0.3f, %0.3f, %0.3f)\n", c(x), c(y), c(z)); 
    fprintf("c10 = (%0.3f, %0.3f, %0.3f)\n", c10(x), c10(y), c10(z));
    fprintf("c20 = (%0.3f, %0.3f, %0.3f)\n", c20(x), c20(y), c20(z));
    fprintf("c1f = (%0.3f, %0.3f, %0.3f)\n", c1f(x), c1f(y), c1f(z));
    fprintf("c2f = (%0.3f, %0.3f, %0.3f)\n", c2f(x), c2f(y), c2f(z));
        %}
    % display angles
    fprintf("theta(1) = %0.3f\n", theta(1));
    fprintf("theta(2) = %0.3f\n", theta(2));
    fprintf("theta(3) = %0.3f\n", theta(3));
    fprintf("theta(4) = %0.3f\n", theta(4));
    fprintf("theta(5) = %0.3f\n", theta(5));
    fprintf("theta(6) = %0.3f\n", theta(6));

end 