%% ____________________
%% INITIALIZATION
clc
clear

% defines x, y, and z array indexes to be used
[x, y, z] = deal(1, 2, 3);

%% ____________________
%% INPUT VALUES
n = [0, 0, 1]; % normal vector
n = n/mag(n); % converts vector 'n' to a unit vector

h = [0, 0, 4]; % center point of the platform
a(x) = 0.0001; % x component of point af

% input user defined lengths
l0 = 2.875;
lf = 2.375;
d1 = 1;
d2 = 1.625;
m = 0.5;
p1 = 1;
p2 = 4.375;

%% ____________________
%% MAIN CODE
output(n, h, a(x), l0, lf, d1, d2, m, p1, p2); % calcuates all theta values and prints 3D graph
         